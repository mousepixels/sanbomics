plots:
	volcano: easily plot volcano plot
		from sanbomics.plots import volcano
tools:
	id_map: map ensembl, entrez, and symbols between eachother
		from sanbomics.tools import id_map